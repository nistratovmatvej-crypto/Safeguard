# SAVEGUARD backend — v0.3.0

Node.js 22 + TypeScript + Fastify API, PostgreSQL + Prisma, Telegram Mini App `initData` verification, server-managed HttpOnly sessions, receipt OCR and Telegram reminder delivery.

## Requirements
- Node.js 22+
- Docker Desktop or PostgreSQL 16/17
- A rotated Telegram bot token (never commit it)

## Local setup

```bash
cp .env.example .env
# Set TELEGRAM_BOT_TOKEN and a random SESSION_SECRET (32+ chars)
docker compose up -d
npm install
npm run db:generate
npm run db:migrate
npm run dev
```

Health check: `http://localhost:3000/health`.

## Endpoints
- `POST /api/v1/auth/telegram` — verify Telegram `initData`, create/find user, issue HttpOnly session.
- `GET /api/v1/auth/me`, `POST /api/v1/auth/logout`.
- `GET /api/v1/dashboard`.
- `POST/DELETE /api/v1/purchases`.
- `POST/DELETE /api/v1/subscriptions`.
- `POST/DELETE /api/v1/reminders` — due reminders are delivered through Telegram every minute.
- `POST /api/v1/ocr/receipt` — multipart image field; JPEG/PNG/WebP up to 8 MB; English and Russian OCR.

## Important operational notes
- Users must have opened the Telegram bot at least once before the bot can send them messages.
- OCR runs locally in the Node process via Tesseract.js; first execution may download language data unless it is provisioned in the deployment image/cache.
- Telegram reminders require a valid bot token and outbound HTTPS access.
- Keep the bot token server-side. Do not expose it to Vite/client variables.
- `initData` is verified server-side and expires after 10 minutes by default.
- Session tokens are random; only SHA-256 hashes are stored in PostgreSQL.
- Use HTTPS in production. Configure `WEB_ORIGIN` to the exact Mini App origin.

## Still required before production
- Connect the actual React Mini App to these endpoints (the connected GitHub `Safeguard` repository was empty when inspected; the existing frontend source was not present in the uploaded archive).
- Add integration tests against a disposable PostgreSQL database and run CI.
- Configure persistent OCR language data in the deployment image.
- Add retry/backoff and a delivery-attempt log for Telegram failures.
- Add CSRF/origin protections appropriate to the final hosting topology and perform a security review.
- Configure deployment secrets, backups, monitoring, and HTTPS.

This is a development foundation, not a production-certified financial service.
