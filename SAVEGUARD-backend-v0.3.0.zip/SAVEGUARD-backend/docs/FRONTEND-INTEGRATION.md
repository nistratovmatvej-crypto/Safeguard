# React Mini App integration contract

1. Read `window.Telegram.WebApp.initData` in the React app. Never send `initDataUnsafe` as proof of identity.
2. POST `{ "initData": window.Telegram.WebApp.initData }` to `/api/v1/auth/telegram` with `credentials: 'include'`.
3. The API validates Telegram's HMAC signature and `auth_date` using the bot token stored only on the server. It then sets an HttpOnly session cookie.
4. For later calls, use `credentials: 'include'`. The cookie is not readable by JavaScript.
5. Use `GET /api/v1/auth/me` to restore the session and `POST /api/v1/auth/logout` to revoke it.

Example:

```ts
const API = import.meta.env.VITE_API_URL;
const initData = window.Telegram?.WebApp?.initData;
if (!initData) throw new Error('Open SAVEGUARD inside Telegram');
const response = await fetch(`${API}/api/v1/auth/telegram`, {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  credentials: 'include', body: JSON.stringify({ initData })
});
if (!response.ok) throw new Error('Telegram authentication failed');
const { user } = await response.json();
```

Available endpoints:
- `GET /health`
- `POST /api/v1/auth/telegram`
- `GET /api/v1/auth/me`
- `POST /api/v1/auth/logout`
- `GET /api/v1/dashboard`
- `POST /api/v1/purchases`
- `DELETE /api/v1/purchases/:id`
- `POST /api/v1/subscriptions`
- `DELETE /api/v1/subscriptions/:id`

This is an initial backend foundation. Receipt file storage, OCR, notification workers, subscription update endpoints, production deployment, CSRF hardening for cookie-authenticated state changes, and end-to-end tests remain to be implemented before production use.
